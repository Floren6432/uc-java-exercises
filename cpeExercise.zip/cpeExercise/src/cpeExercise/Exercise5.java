package cpeExercise;
import java.util.Scanner;

public class Exercise5 {

	public static void main(String[] args) {
		Scanner positiveOrNegative = new Scanner(System.in);
		
		System.out.print("Please enter a number: ");
		int num = positiveOrNegative.nextInt();
		
		if(num < 0) {
			System.out.print("The number is negative!");
		}
		else {
			System.out.print("The number is positve!");
		}
		
		positiveOrNegative.close();
	}

}
