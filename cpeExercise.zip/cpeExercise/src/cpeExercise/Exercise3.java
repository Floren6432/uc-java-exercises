package cpeExercise;
import java.util.Scanner;
public class Exercise3 {

	public static void main(String[] args) {
		Scanner getAge = new Scanner(System.in);
		
		System.out.print("Please enter your age: ");
		int age = getAge.nextInt();
		
		if(age > 18){
			System.out.println("You are old!");
		}
		else {
			System.out.println("You are young!");
		}
		
		getAge.close();
	}

}
