package cpeExercise;

public class Exercise9 {

	public static void main(String[] args) {
		int factorial = 1;
		
		for(int i = 5;i>0;i--) 
		{
			factorial = factorial * i;
			System.out.println(factorial);
		}
	}

}
