package cpeExercise;
import java.util.Scanner;
public class Exercise2 {

	public static void main(String[] args) {
		Scanner inputDetails = new Scanner(System.in);
		
		System.out.print("Enter your name: "); //name
		String name = inputDetails.next();
		
		System.out.print("Enter your age: "); //age
		String age = inputDetails.next ();
		
		System.out.print("Enter your address: "); // address
		String address = inputDetails.next();
		
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		System.out.println("Address: "+address);
		
		inputDetails.close();
	}

}
