package cpeExercise;

public class Exercise7 {

	public static void main(String[] args) {
		int i, num;
		
		for(i=1;i<=5;i++) {
			num = 10 * i;
			System.out.println(num);
		}
	}

}
