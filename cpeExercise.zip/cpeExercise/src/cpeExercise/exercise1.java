package cpeExercise;
import java.util.Scanner;

public class exercise1 {
	public static void main(String[] args) {
		Scanner SimpleCalculator = new Scanner (System.in);
		
		System.out.print("Enter the first number: ");
		int a = SimpleCalculator.nextInt();
		
		System.out.print("Enter the second number: ");
		int b = SimpleCalculator.nextInt();
		
		int sum = a + b;
		int diff = a - b;
		int product = a * b;
		double quotient = a / b;
		
		System.out.println("The sum is : "+ sum);
		System.out.println("The difference is : "+ diff);
		System.out.println("The product is : "+ product);
		System.out.println("The quotient is : "+ quotient);
		
		SimpleCalculator.close();
	}

}
