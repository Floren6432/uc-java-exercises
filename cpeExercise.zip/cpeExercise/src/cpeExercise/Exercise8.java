package cpeExercise;

public class Exercise8 {

	public static void main(String[] args) {
		int i;
		int product = 100;
		
		for(i=1;i<=5;i++) {
			System.out.println(product);
			product = product - 20;
		}
	}

}
