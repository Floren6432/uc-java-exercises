package cpeExercise;
import java.util.Scanner;
public class Exercise6 {

	public static void main(String[] args) {
		Scanner coolCalculator = new Scanner(System.in);
		int a,b;
		//menu
		System.out.println("Menu:");
		System.out.println("1.] Additon");
		System.out.println("2.] Subtraction");
		System.out.println("3.] Multiplication");
		System.out.println("4.] Division");
		System.out.println("5.] Exit");
		System.out.print("Please select an operation: ");
		int choice = coolCalculator.nextInt();
		
		//inputs
		/*System.out.print("Please enter a number: ");
		int a = coolCalculator.nextInt();
		System.out.print("Please enter another number: ");
		int b = coolCalculator.nextInt();*/
		
		switch (choice){
		case 1://addition
			System.out.print("Please enter a number: ");
			a = coolCalculator.nextInt();
			System.out.print("Please enter another number: ");
			b = coolCalculator.nextInt();
			
			int sum = a + b;
			System.out.print(a+ "+" +b+"=" +sum);
			break;
		case 2://subtraction
			System.out.print("Please enter a number: ");
			a = coolCalculator.nextInt();
			System.out.print("Please enter another number: ");
			b = coolCalculator.nextInt();
			
			int difference = a - b;
			System.out.print(a+ "-" +b+"=" +difference);
			break;
		case 3://multiplication
			System.out.print("Please enter a number: ");
			a = coolCalculator.nextInt();
			System.out.print("Please enter another number: ");
			b = coolCalculator.nextInt();
			
			int product = a * b;
			System.out.print(a+ "*" +b+"=" +product);
			break;
		case 4://division
			System.out.print("Please enter a number: ");
			a = coolCalculator.nextInt();
			System.out.print("Please enter another number: ");
			b = coolCalculator.nextInt();
			
			double quotient = a / b;
			System.out.print(a+ "/" +b+"=" +quotient);
			break;
		case 5:
			System.out.print("Exit Successful!");
			break;
		default:
			System.out.print("Invalid Option!");
			break;
		}
		
		coolCalculator.close();
	}

}
