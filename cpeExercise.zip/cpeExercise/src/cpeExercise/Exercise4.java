package cpeExercise;
import java.util.Scanner;

public class Exercise4 {

	public static void main(String[] args) {
		Scanner evenOrOdd = new Scanner(System.in);
		
		System.out.print("Please enter a number: ");
		int number = evenOrOdd.nextInt();
		
		if(number %2 == 0) {
			System.out.print("The number is even!");
		}
		else {
			System.out.print("The number is odd!");
		}
		
		evenOrOdd.close();
	}

}
