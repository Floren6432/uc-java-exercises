/**
 * 
 */
/**
 * @author Floren Go
 *
 */
module cpeExercise {
}